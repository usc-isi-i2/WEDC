RES_SPA_MASSAGE_PARLOR = [
"spa",
"table",
"shower",
"nuru",
"slide",
"therapy",
"therapist",
"bodyrub",
"sauna",
"gel",
"shiatsu",
"jacuzzi"
]
