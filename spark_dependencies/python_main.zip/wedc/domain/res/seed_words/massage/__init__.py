# -*- coding: utf-8 -*-
# @Author: ZwEin
# @Date:   2016-06-29 14:37:07
# @Last Modified by:   ZwEin
# @Last Modified time: 2016-06-29 14:58:40


from spa__massage_parlor import RES_SPA_MASSAGE_PARLOR

RES_MASSAGE = RES_SPA_MASSAGE_PARLOR