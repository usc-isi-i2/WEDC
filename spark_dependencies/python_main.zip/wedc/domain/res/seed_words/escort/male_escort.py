RES_MALE_ESCORT = [
"male",
"playboy",
"gigolo",
"handsome",
"hunk"
]
