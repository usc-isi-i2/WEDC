RES_TRANSSEXUAL = [
"ts",
"tv",
"transvestite",
"tranny",
"tgirl",
"shemale",
"she-male",
"transsexual",
"transexual",
"ladyboy"
]