RES_ESCORT_TXT = [
"click",
"tel",
"sorry",
"call",
"incall",
"outcall",
"hh",
"hr",
"quick",
"quickie",
"hott",
"legged",
"busty"
]