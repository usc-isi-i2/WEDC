# -*- coding: utf-8 -*-
# @Author: ZwEin
# @Date:   2016-06-29 14:37:50
# @Last Modified by:   ZwEin
# @Last Modified time: 2016-06-29 15:07:41


from escort import RES_ESCORT_TXT
from male_escort import RES_MALE_ESCORT
from transsexual_escort import RES_TRANSSEXUAL


RES_ESCORT = RES_ESCORT_TXT + RES_MALE_ESCORT + RES_TRANSSEXUAL