# -*- coding: utf-8 -*-
# @Author: ZwEin
# @Date:   2016-06-29 14:37:34
# @Last Modified by:   ZwEin
# @Last Modified time: 2016-06-29 14:58:30


from labor_ad__legitimate_ import RES_LABEL_AD_LEGITIMATE

RES_JOB_ADS = RES_LABEL_AD_LEGITIMATE