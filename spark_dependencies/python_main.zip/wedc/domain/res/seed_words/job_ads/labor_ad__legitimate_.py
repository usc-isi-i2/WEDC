RES_LABEL_AD_LEGITIMATE = [
"employee",
"manager",
"OSHA",
"license",
"business",
"technician",
"certified",
"degree",
"salary",
"retail",
"401k",
"insurance"
]