from country import RES_COUNTRY
from nationality import RES_NATIONALITY
from male import RES_MALE
from female import RES_FEMALE