"""
from wedc.domain.core.data import loader
# from wedc.domain.vendor.word2vec import w2v

def predict(input):

    # data[0]: pid, used inside program
    # data[1]: sid, unique id for original data
    # data[2]: label, 0 if unknown 
    # data[3]: extraction (tokens), split by space, extracted from original content
    dataset = generate_compressed_data(input)
    
"""
    


