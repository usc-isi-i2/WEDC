

import os
# from digoie.utils.sys_info import *


##################################################################
#                             Path                               #  
##################################################################

## top-level
__root_dir__ = os.path.abspath(os.path.join(__file__,"..","..", ".."))

__res_dir__ = os.path.join(__root_dir__, 'domain', 'res')

## app path - user home dir
# __app_dir__ = os.path.join(do_user_path(), 'dig_openie')

## res
# __app_res_dir__ = os.path.join(__app_dir__, 'res')








